package gr4.controllers;

import gr4.dane;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class Controller extends Component implements Initializable {
    @FXML
    private Button btnRead;

    @Override
    public void initialize(URL location, ResourceBundle resources) {

    }

    public void onClickEvent(javafx.scene.input.MouseEvent event) throws IOException {
        if(event.getSource()==btnRead) {
            String sciezkaDoPlik;
            JFileChooser otworz= new JFileChooser();
            int wynik = otworz.showOpenDialog(this);
            if(wynik== JFileChooser.APPROVE_OPTION)
            {
                dane dane = new dane();
                sciezkaDoPlik= otworz.getSelectedFile().getPath();
                dane.odczytajPlik(sciezkaDoPlik);
                for(int i = 0; i<dane.daneOdczytane.length; i++)
                {
                    for(int j = 0; j<dane.daneOdczytane[i].length; j++){
                        System.out.print(dane.daneOdczytane[i][j]+" ");
                    }
                    System.out.print("\n");
                }

            }
        }
    }
}
